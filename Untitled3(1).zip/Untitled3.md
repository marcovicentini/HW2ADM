
# HW2ADM



# RQ4
What is the most common way of payments? Discover the way payments are executed in each borough and visualize the number of payments for any possible means. Then run the Chi-squared test to see whether the method of payment is correlated to the borough. Then, comment the results.

In the first part of the code we create DataFrames from the data for each month:
```python
import pandas as pd
import matplotlib.pyplot as plt
fields =['PULocationID','payment_type']
dic={fields[0]:int, fields[1]:int}
str='C:\Users\Farid\Desktop\HW2-ADM-1\yellow_tripdata_2018-01.csv'
jan = pd.read_csv(r str, sep=',', nrows=10, dtype=dic, usecols=fields)
feb = pd.read_csv(r str, sep=',', nrows=10, dtype=dic, usecols=fields)
mar = pd.read_csv(r str, sep=',', nrows=10, dtype=dic, usecols=fields)
apr = pd.read_csv(r str, sep=',', nrows=10, dtype=dic, usecols=fields)
may = pd.read_csv(r str, sep=',', nrows=10, dtype=dic, usecols=fields)
jun = pd.read_csv(r str, sep=',', nrows=10, dtype=dic, usecols=fields)
```


```python
import pandas as pd
import matplotlib.pyplot as plt
fields =['PULocationID','payment_type']
dic={fields[0]:int, fields[1]:int}

jan = pd.read_csv(r'C:\Users\Farid\Desktop\HW2-ADM-1\yellow_tripdata_2018-01.csv', sep=',', nrows=10, dtype=dic, usecols=fields)
feb = pd.read_csv(r'C:\Users\Farid\Desktop\HW2-ADM-1\yellow_tripdata_2018-01.csv', sep=',', nrows=10, dtype=dic, usecols=fields)
mar = pd.read_csv(r'C:\Users\Farid\Desktop\HW2-ADM-1\yellow_tripdata_2018-01.csv', sep=',', nrows=10, dtype=dic, usecols=fields)
apr = pd.read_csv(r'C:\Users\Farid\Desktop\HW2-ADM-1\yellow_tripdata_2018-01.csv', sep=',', nrows=10, dtype=dic, usecols=fields)
may = pd.read_csv(r'C:\Users\Farid\Desktop\HW2-ADM-1\yellow_tripdata_2018-01.csv', sep=',', nrows=10, dtype=dic, usecols=fields)
jun = pd.read_csv(r'C:\Users\Farid\Desktop\HW2-ADM-1\yellow_tripdata_2018-01.csv', sep=',', nrows=10, dtype=dic, usecols=fields)
```

In the second part of the code we create auxiliary dictionaries, which help us to count frequencies:
```python
frames=[jan,feb,mar,apr,may,jun]
dictmonth={}
dictmonthset={}
for i in frames:
    month = i
    monthdic = month.to_dict('list')
    lenmonth = len(monthdic['PULocationID'])
    for i in range(lenmonth):
       if (monthdic['PULocationID'])[i] not in dictmonth: dictmonth[month['PULocationID'][i]] = []
       dictmonth[(monthdic['PULocationID'])[i]].append((monthdic['payment_type'])[i])
    for i in dictmonth:
        dictmonthset[i]=set(dictmonth[i])
```


```python
frames=[jan,feb,mar,apr,may,jun]
dictmonth={}
dictmonthset={}
for i in frames:
    month = i
    monthdic = month.to_dict('list')
    lenmonth = len(monthdic['PULocationID'])
    for i in range(lenmonth):
       if (monthdic['PULocationID'])[i] not in dictmonth: dictmonth[month['PULocationID'][i]] = []
       dictmonth[(monthdic['PULocationID'])[i]].append((monthdic['payment_type'])[i])
    for i in dictmonth:
        dictmonthset[i]=set(dictmonth[i])
```

In the third part we count frequencies:
```python
import pandas as pd
import matplotlib.pyplot as plt
month2 = pd.DataFrame(0, index=sorted(dictmonth)+['total'], columns=[1, 2, 3, 4, 5, 6,'total'], dtype=int)
month22 = pd.DataFrame(0, index=sorted(dictmonth), columns=[1, 2, 3, 4], dtype=int)
for i in dictmonthset:
    for j in dictmonthset[i]:
        if j>4: month2.loc[i, j] = float(dictmonth[i].count(j))
        else :  month22.loc[i, j]=month2.loc[i, j] = float(dictmonth[i].count(j))
for i in dictmonth:
    month2.loc[i, 'total']=sum(month2.loc[i])
for i in range(1,7):
    month2.loc['total', i]=sum(month2[i])

if sum(month2['total'])==sum(month2.loc['total']):
    month2.loc['total', 'total']=sum(month2['total'])
else: month2.loc['total', 'total']= 'error'
month22[:129].plot.bar(subplots=True, fontsize=72, figsize=(170,70))
month22[129:].plot.bar(subplots=True, fontsize=72, figsize=(170,70))
plt.show()
print(month2)
```


```python
import pandas as pd
import matplotlib.pyplot as plt
month2 = pd.DataFrame(0, index=sorted(dictmonth)+['total'], columns=[1, 2, 3, 4, 5, 6,'total'], dtype=int)
month22 = pd.DataFrame(0, index=sorted(dictmonth), columns=[1, 2, 3, 4], dtype=int)
for i in dictmonthset:
    for j in dictmonthset[i]:
        if j>4: month2.loc[i, j] = float(dictmonth[i].count(j))
        else :  month22.loc[i, j]=month2.loc[i, j] = float(dictmonth[i].count(j))
for i in dictmonth:
    month2.loc[i, 'total']=sum(month2.loc[i])
for i in range(1,7):
    month2.loc['total', i]=sum(month2[i])

if sum(month2['total'])==sum(month2.loc['total']):
    month2.loc['total', 'total']=sum(month2['total'])
else: month2.loc['total', 'total']= 'error'
month22[:len(month22)//2].plot.bar(subplots=True, fontsize=72, figsize=(170,70))
month22[len(month22)//2:].plot.bar(subplots=True, fontsize=72, figsize=(170,70))
plt.show()
print(month2)
```


![png](output_5_0.png)



![png](output_5_1.png)


              1     2  3  4  5  6  total
    41      0.0   6.0  0  0  0  0    6.0
    50      6.0   0.0  0  0  0  0    6.0
    140     0.0   6.0  0  0  0  0    6.0
    143     0.0   6.0  0  0  0  0    6.0
    170     0.0   6.0  0  0  0  0    6.0
    238     6.0   0.0  0  0  0  0    6.0
    239     6.0   6.0  0  0  0  0   12.0
    246     6.0   0.0  0  0  0  0    6.0
    262     6.0   0.0  0  0  0  0    6.0
    total  30.0  30.0  0  0  0  0   60.0
    

Here we count the table of expected values:
```python
import pandas as pd
month3= pd.DataFrame(0, index=sorted(dictmonth), columns=[1, 2, 3, 4, 5, 6], dtype=int)
for i in dictmonth:
    for j in range(1,7):
        mn2it=month2.loc[i, "total"]
        mn2tj=month2.loc["total", j]
        mn2tt=month2.loc['total', 'total']
        month3.loc[i,j]= (mn2it*mn2tj)/mn2tt
```


```python
import pandas as pd
month3= pd.DataFrame(0, index=sorted(dictmonth), columns=[1, 2, 3, 4, 5, 6], dtype=int)
for i in dictmonth:
    for j in range(1,7):
        mn2it=month2.loc[i, "total"]
        mn2tj=month2.loc["total", j]
        mn2tt=month2.loc['total', 'total']
        month3.loc[i,j]= (mn2it*mn2tj)/mn2tt
```

Here we compute chi squared statistics: 
```python
month4= pd.DataFrame(0, index=sorted(dictmonth), columns=[1, 2, 3, 4, 5, 6], dtype=int)
for i in dictmonth:
    for j in range(1,7):
        mn2ij=month2.loc[i,j]
        mn3ij=month3.loc[i, j]
        if mn3ij!=0:  month4.loc[i, j]=((mn2ij-mn3ij)**2)/mn3ij
        else: month4.loc[i,j] = 0
print('chi^2=', sum(month4))
```


```python
month4= pd.DataFrame(0, index=sorted(dictmonth), columns=[1, 2, 3, 4, 5, 6], dtype=int)
for i in dictmonth:
    for j in range(1,7):
        mn2ij=month2.loc[i,j]
        mn3ij=month3.loc[i, j]
        if mn3ij!=0:  month4.loc[i, j]=((mn2ij-mn3ij)**2)/mn3ij
        else: month4.loc[i,j] = 0
print('chi^2=', sum(month4))
```

    chi^2= 21
    
